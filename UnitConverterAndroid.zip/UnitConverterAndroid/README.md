# UnitConverterAndroid

<IN PROGRESS> Convertion - temperature, number and length converter.

TESTED ON: Motorola Moto G6 Plus

NAVIGATION
<p align="center">
  <img src="https://raw.githubusercontent.com/YunaAnn/UnitConverterAndroid/master/Screenshots/navigation.png" width="400" title="hover text">

TEMPERATURE CONVERSION
  <p align="center">
  <img src="https://raw.githubusercontent.com/YunaAnn/UnitConverterAndroid/master/Screenshots/temperature.png" width="400" title="hover text">
  <img src="https://raw.githubusercontent.com/YunaAnn/UnitConverterAndroid/master/Screenshots/temperature_conversion.png" width="400" title="hover text">
  <img src="https://raw.githubusercontent.com/YunaAnn/UnitConverterAndroid/master/Screenshots/temperature_error.png" width="400" title="hover text">
  
LENGTH CONVERSION
   <p align="center">
  <img src="https://raw.githubusercontent.com/YunaAnn/UnitConverterAndroid/master/Screenshots/length.png" width="400" title="hover text">
  <img src="https://raw.githubusercontent.com/YunaAnn/UnitConverterAndroid/master/Screenshots/length_conversion.png" width="400" title="hover text">
  <img src="https://raw.githubusercontent.com/YunaAnn/UnitConverterAndroid/master/Screenshots/length_error.png" width="400" title="hover text">
  
NUMBER CONVERSION
   <p align="center">
  <img src="https://raw.githubusercontent.com/YunaAnn/UnitConverterAndroid/master/Screenshots/number.png" width="400" title="hover text">
  <img src="https://raw.githubusercontent.com/YunaAnn/UnitConverterAndroid/master/Screenshots/number_conversion.png" width="400" title="hover text">
  <img src="https://raw.githubusercontent.com/YunaAnn/UnitConverterAndroid/master/Screenshots/number_error.png" width="400" title="hover text">
  
  ---------
  
TODO:
- possible visual changes
- minor fixes

DONE:
- Navigation drawer
- UI
- temperature conversion
- length conversion
- number conversion